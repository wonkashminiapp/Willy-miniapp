# NOVA BOT — Réseaux

Mini-site statique mobile-first pour présenter et ouvrir le canal Telegram public.

## Publication gratuite avec GitHub Pages

1. Dans le dépôt GitHub `nova-bot`, choisissez **Add file → Upload files**.
2. Envoyez `index.html`, `style.css`, `script.js` et `README.md` (ou déposez le contenu du ZIP).
3. Cliquez sur **Commit changes**.
4. Ouvrez **Settings → Pages**.
5. Dans **Build and deployment**, choisissez **Deploy from a branch**.
6. Sélectionnez `main` et `/ (root)`, puis **Save**.

Le site sera publié à `https://VOTRE-NOM-GITHUB.github.io/nova-bot/` après quelques minutes.

## Modifier le canal

Le lien Telegram actuel est `https://t.me/lienwillywonkash`. Pour le changer, remplacez ce lien dans les deux occurrences de `index.html`.

## Limites

Cette version est une page d'accès au canal. Elle ne permet pas de lire les messages privés, d'administrer le canal ou de publier en votre nom. Ces actions nécessitent des droits Telegram et, pour certaines fonctions, un serveur ou un bot configuré séparément.
