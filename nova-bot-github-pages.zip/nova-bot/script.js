// NOVA BOT — mini application statique pour GitHub Pages
// Le lien du canal est défini dans index.html.
document.title = "NOVA BOT — Réseaux";
